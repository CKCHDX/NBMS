#!/bin/bash

echo "============================================================"
echo "  Nokia 2760 Bluetooth Chat Client Launcher"
echo "  CKCHDX - Oscyra Solutions"
echo "============================================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 is not installed!"
    echo "Install with: sudo apt-get install python3 python3-pip"
    exit 1
fi

# Check if dependencies are installed
echo "[*] Checking dependencies..."
if ! python3 -c "import bluetooth" 2>/dev/null; then
    echo "[!] Installing dependencies..."
    sudo apt-get update
    sudo apt-get install -y bluetooth libbluetooth-dev
    pip3 install -r requirements.txt
fi

echo ""
echo "[*] Starting Bluetooth Chat Client..."
echo ""

# Run the client
python3 bluetooth_client.py
