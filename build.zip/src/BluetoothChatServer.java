import java.io.*;
import javax.microedition.io.*;
import javax.bluetooth.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

/**
 * Bluetooth SPP Chat Server for Nokia 2760
 * Listens for incoming connections and handles plaintext messages
 */
public class BluetoothChatServer extends MIDlet implements CommandListener {

    private Display display;
    private Form mainForm;
    private TextField statusField;
    private Command exitCommand;
    private Command startServerCommand;

    private StreamConnectionNotifier serverNotifier;
    private StreamConnection connection;
    private boolean isServerRunning = false;

    // SPP UUID - Standard Serial Port Profile
    private static final String SPP_UUID = "0000110100001000800000805F9B34FB";

    public BluetoothChatServer() {
        display = Display.getDisplay(this);

        // Create UI
        mainForm = new Form("BT Chat Server");
        statusField = new TextField("Status:", "Not started", 50, TextField.ANY);
        mainForm.append(statusField);

        startServerCommand = new Command("Start Server", Command.OK, 1);
        exitCommand = new Command("Exit", Command.EXIT, 2);

        mainForm.addCommand(startServerCommand);
        mainForm.addCommand(exitCommand);
        mainForm.setCommandListener(this);
    }

    protected void startApp() {
        display.setCurrent(mainForm);
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean unconditional) {
        stopServer();
    }

    public void commandAction(Command c, Displayable d) {
        if (c == startServerCommand) {
            if (!isServerRunning) {
                new Thread(new Runnable() {
                    public void run() {
                        startServer();
                    }
                }).start();
            }
        } else if (c == exitCommand) {
            destroyApp(true);
            notifyDestroyed();
        }
    }

    private void startServer() {
        try {
            updateStatus("Initializing Bluetooth...");

            // Get local device
            LocalDevice localDevice = LocalDevice.getLocalDevice();
            localDevice.setDiscoverable(DiscoveryAgent.GIAC);

            String deviceName = localDevice.getFriendlyName();
            String deviceAddr = localDevice.getBluetoothAddress();

            updateStatus("Device: " + deviceName);
            updateStatus("Address: " + deviceAddr);

            // Create server connection string
            String connectionURL = "btspp://localhost:" + SPP_UUID + 
                                 ";name=ChatPortal;authorize=false;authenticate=false;encrypt=false";

            updateStatus("Opening server...");
            serverNotifier = (StreamConnectionNotifier) Connector.open(connectionURL);

            isServerRunning = true;
            updateStatus("Server started!");
            updateStatus("Waiting for connection...");

            // Accept connection (blocking call)
            connection = serverNotifier.acceptAndOpen();

            // Get remote device info
            RemoteDevice remoteDevice = RemoteDevice.getRemoteDevice(connection);
            String remoteName = "Unknown";
            try {
                remoteName = remoteDevice.getFriendlyName(false);
            } catch (Exception e) {
                remoteName = remoteDevice.getBluetoothAddress();
            }

            updateStatus("Connected to: " + remoteName);

            // Handle communication
            handleCommunication();

        } catch (Exception e) {
            updateStatus("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            stopServer();
        }
    }

    private void handleCommunication() {
        InputStream inStream = null;
        OutputStream outStream = null;

        try {
            inStream = connection.openInputStream();
            outStream = connection.openOutputStream();

            updateStatus("Chat started!");

            byte[] buffer = new byte[1024];
            int bytesRead;

            // Read messages in loop
            while (isServerRunning) {
                bytesRead = inStream.read(buffer);

                if (bytesRead > 0) {
                    String message = new String(buffer, 0, bytesRead);
                    message = message.trim();

                    updateStatus("Received: " + message);

                    // Send acknowledgment with received message
                    String response = "ACK: " + message + "\n";
                    outStream.write(response.getBytes());
                    outStream.flush();
                }
            }

        } catch (IOException e) {
            updateStatus("Connection error: " + e.getMessage());
        } finally {
            try {
                if (inStream != null) inStream.close();
                if (outStream != null) outStream.close();
            } catch (IOException e) {
            }
        }
    }

    private void stopServer() {
        isServerRunning = false;

        try {
            if (connection != null) {
                connection.close();
                connection = null;
            }
            if (serverNotifier != null) {
                serverNotifier.close();
                serverNotifier = null;
            }
            updateStatus("Server stopped");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateStatus(final String message) {
        display.callSerially(new Runnable() {
            public void run() {
                String current = statusField.getString();
                statusField.setString(current + "\n" + message);
            }
        });
    }
}
