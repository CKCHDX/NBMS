# 🔧 TROUBLESHOOTING GUIDE

## Nokia 2760 Issues

### App Won't Compile

**Problem:** Java compilation errors

**Solutions:**
```bash
# Make sure you have Java ME libraries in classpath
# Check for:
- cldcapi11.jar
- midpapi20.jar  
- jsr082.jar (Bluetooth API)

# Verify Java source version
javac -source 1.3 -target 1.3 *.java
```

### App Won't Install

**Problem:** "Application error" or "Invalid file"

**Solutions:**
1. Check JAR and JAD file sizes match:
   ```bash
   ls -l BTChatServer.jar
   # Size must match MIDlet-Jar-Size in JAD
   ```

2. Verify manifest permissions:
   - Open manifest.mf
   - Check Bluetooth permissions are listed

3. Try signing the JAR (optional):
   ```bash
   jarsigner -keystore mykey.keystore BTChatServer.jar myalias
   ```

### Bluetooth Permissions Denied

**Problem:** "Bluetooth access denied"

**Solutions:**
1. Go to Settings → Applications → BTChatServer
2. Set permissions to "Always allow"
3. Restart the app

### Server Won't Start

**Problem:** "Bluetooth error" on startup

**Solutions:**
1. Enable Bluetooth: Settings → Connectivity → Bluetooth → On
2. Make device discoverable: Settings → Bluetooth → My phone's visibility → Visible to all
3. Restart phone
4. Check battery level (low battery can disable Bluetooth)

### Connection Drops Immediately

**Problem:** Connected but disconnects right away

**Solutions:**
1. Remove pairing from both devices
2. Re-pair with correct PIN (usually 0000 or 1234)
3. Make sure no other app is using Bluetooth
4. Keep devices within 5 meters

---

## Laptop Client Issues

### PyBluez Won't Install (Windows)

**Problem:** "error: Microsoft Visual C++ 14.0 is required"

**Solutions:**
1. Install Visual C++ Build Tools:
   - Download from: https://visualstudio.microsoft.com/visual-cpp-build-tools/
   - Select "Desktop development with C++"
   - Install

2. Or use precompiled wheel:
   ```bash
   pip install wheel
   pip install pybluez‑0.23‑cp39‑cp39‑win_amd64.whl
   ```

3. Alternative - Use PyBluez2:
   ```bash
   pip install pybluez2
   # Then modify imports in code:
   import bluetooth  # stays the same
   ```

### PyBluez Won't Install (Linux)

**Problem:** "bluetooth/bluetooth.h: No such file"

**Solutions:**
```bash
# Install Bluetooth development libraries
sudo apt-get update
sudo apt-get install bluetooth bluez libbluetooth-dev

# Install Python package
pip3 install pybluez

# If still fails:
sudo apt-get install python3-bluez
```

### Can't Import Bluetooth Module

**Problem:** `ModuleNotFoundError: No module named 'bluetooth'`

**Solutions:**
```bash
# Check if installed
pip list | grep pybluez

# If not installed:
pip install pybluez

# On Linux, also try:
sudo apt-get install python3-bluez
```

### Device Discovery Fails

**Problem:** "No devices found"

**Solutions:**

**Windows:**
1. Enable Bluetooth: Settings → Bluetooth → On
2. Run Python as Administrator
3. Check Windows Defender Firewall

**Linux:**
```bash
# Start Bluetooth service
sudo systemctl start bluetooth
sudo systemctl status bluetooth

# Scan manually
hcitool scan

# Check adapter
hciconfig hci0 up
```

### Connection Refused

**Problem:** `bluetooth.btcommon.BluetoothError: [Errno 111] Connection refused`

**Solutions:**
1. Make sure Nokia app is running and showing "Waiting for connection..."
2. Verify Nokia MAC address is correct:
   ```bash
   hcitool scan
   ```
3. Check pairing status - devices must be paired first
4. Try removing and re-pairing
5. Verify port number (default is 1)

### Permission Denied (Linux)

**Problem:** `bluetooth.btcommon.BluetoothError: [Errno 13] Permission denied`

**Solutions:**
```bash
# Add user to bluetooth group
sudo usermod -a -G bluetooth $USER

# Or run with sudo (not recommended)
sudo python3 bluetooth_client.py

# Check /dev/rfcomm permissions
ls -l /dev/rfcomm*
```

### Encryption Errors

**Problem:** `[!] Encryption error: ...`

**Solutions:**
1. Install PyCryptodome:
   ```bash
   pip install pycryptodome
   ```

2. If using PyCrypto (old), switch to PyCryptodome:
   ```bash
   pip uninstall pycrypto
   pip install pycryptodome
   ```

3. Check key matches between Nokia and Python:
   - Nokia: `SECRET_KEY = "MySecretKey12345"`
   - Python: `SECRET_KEY = b'MySecretKey12345'`

---

## Connection Issues

### Devices Won't Pair

**Problem:** Pairing fails or asks for PIN repeatedly

**Solutions:**

**On Nokia 2760:**
1. Settings → Connectivity → Bluetooth → Paired devices
2. Delete existing pairing if present
3. Make device visible

**On Laptop:**
1. Remove existing pairing
2. Search for devices
3. Select Nokia 2760
4. Enter PIN when prompted (try: 0000, 1234, or check Nokia screen)

### Pairing Works But Connection Fails

**Problem:** Paired but can't connect

**Solutions:**
1. Make sure Nokia app is running FIRST
2. Wait for "Waiting for connection..." message
3. Then run laptop client
4. Check SPP profile is supported:
   ```bash
   sdptool browse XX:XX:XX:XX:XX:XX
   # Look for "Serial Port" service
   ```

### Unstable Connection

**Problem:** Connection drops frequently

**Solutions:**
1. **Reduce distance:** Keep devices within 3-5 meters
2. **Remove obstacles:** Bluetooth doesn't penetrate walls well
3. **Avoid interference:**
   - Turn off WiFi temporarily
   - Move away from microwaves
   - Disable other Bluetooth devices
4. **Check battery:** Low battery reduces Bluetooth range
5. **Update firmware:** (if available for Nokia)

---

## Data Transfer Issues

### Messages Not Received

**Problem:** Send works but Nokia doesn't show message

**Solutions:**
1. Check message format - must end with \n:
   ```python
   sock.send(("Hello\n").encode('utf-8'))
   ```

2. Verify Nokia app is reading from input stream
3. Check buffer size (default 1024 bytes)
4. Try sending shorter messages first

### Garbled Messages

**Problem:** Messages appear corrupted or unreadable

**Solutions:**
1. Check encoding matches (UTF-8 on both sides)
2. Disable encryption temporarily to test
3. Verify message length < 1024 bytes
4. Check for null bytes in message

### Encryption Mismatch

**Problem:** "Decryption error" on Nokia or laptop

**Solutions:**
1. Verify same key on both sides:
   ```java
   // Nokia
   private static final String SECRET_KEY = "MySecretKey12345";
   ```
   ```python
   # Python
   SECRET_KEY = b'MySecretKey12345'
   ```

2. Check encryption mode (ECB on both)
3. Verify hex encoding/decoding
4. Test with encryption disabled first

---

## Build Issues

### Ant Build Fails

**Problem:** `build.xml` errors

**Solutions:**
1. Install Apache Ant:
   ```bash
   # Windows: Download from ant.apache.org
   # Linux:
   sudo apt-get install ant
   ```

2. Set WTK_HOME in build.xml:
   ```xml
   <property name="wtk.home" value="C:/WTK2.5.2"/>
   ```

3. Check Java ME SDK is installed

### Preverification Fails

**Problem:** Preverify errors during build

**Solutions:**
1. Make sure preverify tool is in PATH
2. Check CLDC/MIDP jars are available
3. Try manual preverification:
   ```bash
   preverify -classpath lib/cldcapi11.jar -d verified build
   ```

### JAR Too Large

**Problem:** "File too large for device"

**Solutions:**
1. Remove unused imports
2. Optimize code (remove debug statements)
3. Use ProGuard to shrink JAR:
   ```bash
   proguard @config.pro
   ```

---

## Runtime Errors

### OutOfMemoryError on Nokia

**Problem:** App crashes with memory error

**Solutions:**
1. Reduce buffer size in code
2. Close streams when not in use
3. Limit message history length
4. Use System.gc() to suggest garbage collection

### Socket Timeout

**Problem:** Connection times out waiting for data

**Solutions:**
```python
# Increase timeout
sock.settimeout(10)  # 10 seconds

# Or handle timeout gracefully
try:
    data = sock.recv(1024)
except socket.timeout:
    print("No response, continuing...")
```

---

## Testing Commands

### Check Bluetooth on Linux

```bash
# Check adapter
hciconfig

# Scan for devices
hcitool scan

# Get device info
hcitool info XX:XX:XX:XX:XX:XX

# Check services (SPP)
sdptool browse XX:XX:XX:XX:XX:XX
```

### Test Python Bluetooth

```python
import bluetooth

# Test discovery
devices = bluetooth.discover_devices()
print(devices)

# Test socket
sock = bluetooth.BluetoothSocket(bluetooth.RFCOMM)
print("Bluetooth socket created successfully")
```

### Debug Nokia App

Add debug output:
```java
System.out.println("Debug: Connection established");
updateStatus("Debug: " + message);
```

View output in:
- WTK console (during emulator testing)
- Device logs (if accessible)

---

## Quick Fixes

### Reset Everything

1. **Nokia 2760:**
   - Exit app
   - Settings → Bluetooth → Paired devices → Delete all
   - Restart phone
   - Reinstall app

2. **Laptop:**
   - Remove pairing
   - Restart Bluetooth service:
     ```bash
     # Linux
     sudo systemctl restart bluetooth

     # Windows
     # Disable/enable Bluetooth adapter
     ```
   - Reinstall Python packages:
     ```bash
     pip uninstall pybluez pycryptodome
     pip install pybluez pycryptodome
     ```

3. **Test with minimal code:**
   - Disable encryption
   - Use short messages
   - Test pairing first
   - Then add features back

---

## Still Having Issues?

1. **Check logs:**
   - Nokia: Look for error messages on screen
   - Python: Run with -v flag for verbose output

2. **Test components separately:**
   - Test pairing without app
   - Test app in emulator first
   - Test Python script locally

3. **Ask for help:**
   - Check Nokia 2760 forums
   - PyBluez GitHub issues
   - Stack Overflow (tag: bluetooth, java-me)

4. **Contact developer:**
   - GitHub: https://github.com/CKCHDX
   - Email: support@oscyra.solutions

---

**Remember:** Bluetooth can be finicky. Be patient, test methodically, and verify each step works before moving on!
