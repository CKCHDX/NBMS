"""
AES encryption module for Bluetooth messages
Uses the same key as Nokia 2760 server for compatibility
"""

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import binascii

# Must match the key in MessageEncryption.java
SECRET_KEY = b'MySecretKey12345'  # 16 bytes for AES-128

def encrypt_message(plaintext):
    """
    Encrypt a message using AES-128
    Returns hex-encoded ciphertext
    """
    try:
        cipher = AES.new(SECRET_KEY, AES.MODE_ECB)

        # Pad message to block size
        padded_data = pad(plaintext.encode('utf-8'), AES.block_size)

        # Encrypt
        ciphertext = cipher.encrypt(padded_data)

        # Convert to hex string (matches Java implementation)
        return binascii.hexlify(ciphertext).decode('utf-8')

    except Exception as e:
        print(f"[!] Encryption error: {e}")
        return plaintext

def decrypt_message(ciphertext_hex):
    """
    Decrypt a hex-encoded AES-128 ciphertext
    Returns plaintext string
    """
    try:
        cipher = AES.new(SECRET_KEY, AES.MODE_ECB)

        # Convert hex to bytes
        ciphertext = binascii.unhexlify(ciphertext_hex)

        # Decrypt
        padded_plaintext = cipher.decrypt(ciphertext)

        # Remove padding
        plaintext = unpad(padded_plaintext, AES.block_size)

        return plaintext.decode('utf-8')

    except Exception as e:
        print(f"[!] Decryption error: {e}")
        return ciphertext_hex

def test_encryption():
    """Test encryption/decryption"""
    test_message = "Hello Nokia 2760!"
    print(f"Original: {test_message}")

    encrypted = encrypt_message(test_message)
    print(f"Encrypted: {encrypted}")

    decrypted = decrypt_message(encrypted)
    print(f"Decrypted: {decrypted}")

    assert test_message == decrypted, "Encryption test failed!"
    print("[+] Encryption test passed!")

if __name__ == "__main__":
    test_encryption()
