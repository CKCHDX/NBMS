# 🚀 QUICK START GUIDE

## Step 1: Build Nokia 2760 App

### Option A: Using Java ME SDK (Easiest)

1. Install Sun WTK 2.5.2 or Nokia SDK
2. Open WTK
3. File → New Project
   - Project Name: BTChatServer
   - MIDlet Class: BluetoothChatServer
4. Copy files:
   - `nokia_server/src/*.java` → WTK project `src/`
   - `nokia_server/resources/manifest.mf` → WTK project `res/META-INF/`
5. Click "Build"
6. Find JAR in WTK `apps/BTChatServer/bin/`

### Option B: Using Ant (Command Line)

```bash
cd nokia_server
ant build
```

Files created in `dist/`:
- BTChatServer.jar
- BTChatServer.jad

## Step 2: Install on Nokia 2760

### Via Bluetooth:
1. Enable Bluetooth on phone and laptop
2. Send JAR + JAD files via Bluetooth
3. On Nokia: Accept files
4. Menu → Applications → Install

### Via USB (if available):
1. Connect Nokia with USB cable
2. Copy JAR and JAD to phone memory
3. Navigate to files and install

## Step 3: Setup Laptop Client

```bash
cd laptop_client

# Install dependencies
pip install -r requirements.txt

# On Linux, also install:
sudo apt-get install bluetooth libbluetooth-dev
```

## Step 4: Run the System

### On Nokia 2760:
1. Menu → Applications → BT Chat Server
2. Press "Start Server"
3. Note the MAC address shown on screen

### On Laptop:
```bash
python bluetooth_client.py
```

Follow the prompts:
1. Enter Nokia MAC address (or scan)
2. Choose encryption (y/n)
3. Start chatting!

## Troubleshooting

### Nokia won't start:
- Restart phone
- Enable Bluetooth in Settings
- Check battery level

### Laptop can't find device:
```bash
# Linux
sudo systemctl restart bluetooth
hcitool scan

# Windows
# Disable/enable Bluetooth adapter
```

### Connection fails:
1. Remove pairing on both devices
2. Re-pair (PIN: 0000 or 1234)
3. Try again

---

**That's it! You're ready to chat via Bluetooth SPP! 🎉**
