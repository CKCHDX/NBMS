# Nokia 2760 Bluetooth Chat System

A complete Bluetooth SPP (Serial Port Profile) encrypted chat system between Nokia 2760 and a laptop.

**Created by:** CKCHDX  
**Project:** Bluetooth Chat Portal  
**Date:** November 2025

---

## System Architecture

```
Nokia 2760 (Server)          Bluetooth SPP          Laptop (Client)
──────────────────          ──────────────          ───────────────
Java ME Application    ←──→  RFCOMM Channel    ←──→  Python Client
Listens on SPP UUID          Encrypted Data         Sends Messages
Port 1                       AES-128                 Receives ACK
```

---

## Features

✅ Bluetooth SPP server on Nokia 2760  
✅ Python client for Windows/Linux laptops  
✅ Optional AES-128 encryption  
✅ Interactive chat interface  
✅ Device discovery and automatic pairing  
✅ Connection status monitoring  
✅ Error handling and reconnection support  

---

## Part 1: Nokia 2760 Setup

### Requirements
- Nokia 2760 phone
- Java ME SDK (Sun WTK 2.5.2 or Nokia SDK)
- USB cable or Bluetooth for deployment

### Building the Nokia App

1. **Install Java ME SDK:**
   - Download Sun Java Wireless Toolkit 2.5.2
   - Or use Nokia SDK for Java ME

2. **Create project structure:**
   ```
   nokia_server/
   ├── src/
   │   ├── BluetoothChatServer.java
   │   └── MessageEncryption.java
   └── resources/
       └── manifest.mf
   ```

3. **Compile with WTK:**
   ```bash
   # Open Sun WTK
   # Create new project: "BTChatServer"
   # Copy Java files to src/
   # Copy manifest.mf to res/
   # Build project
   ```

4. **Or use command line:**
   ```bash
   # Set CLASSPATH to include MIDP and CLDC libraries
   javac -bootclasspath midpapi20.jar:cldcapi11.jar \
         -d build/ src/*.java

   # Create JAR
   jar cmf manifest.mf BTChatServer.jar -C build/ .

   # Create JAD (descriptor)
   # Edit BTChatServer.jad with correct file size
   ```

5. **Deploy to Nokia 2760:**
   - Transfer JAR and JAD files via Bluetooth
   - Or use USB cable
   - Install on phone: Menu → Applications → Install

### Running on Nokia 2760

1. Launch "BT Chat Server" from Applications
2. Press "Start Server" button
3. Phone will show:
   - Device name
   - Bluetooth address
   - "Waiting for connection..."
4. Keep app running and phone unlocked

---

## Part 2: Laptop Setup

### Requirements
- Windows 10/11 or Linux
- Python 3.7+
- Bluetooth adapter

### Installation

**On Windows:**
```bash
# Install Python dependencies
pip install pybluez pycryptodome

# Note: On Windows, PyBluez may need Microsoft C++ Build Tools
# Download from: https://visualstudio.microsoft.com/visual-cpp-build-tools/
```

**On Linux (Debian/Ubuntu):**
```bash
# Install system dependencies
sudo apt-get update
sudo apt-get install bluetooth libbluetooth-dev python3-pip

# Install Python packages
pip3 install pybluez pycryptodome
```

### Running the Laptop Client

1. **Pair Nokia 2760 with laptop:**
   - Windows: Settings → Bluetooth → Add device
   - Linux: `bluetoothctl` → `pair XX:XX:XX:XX:XX:XX`
   - PIN is usually `0000` or `1234`

2. **Get Nokia MAC address:**

   **Windows:** Check Bluetooth settings or Device Manager

   **Linux:**
   ```bash
   hcitool scan
   ```

3. **Run the client:**
   ```bash
   python bluetooth_client.py
   ```

4. **Follow prompts:**
   - Enter Nokia MAC address (or scan)
   - Choose whether to use encryption
   - Start chatting!

---

## Usage Example

### Terminal Output

```
============================================================
     Nokia 2760 Bluetooth Chat Client
     Created by CKCHDX
============================================================

[?] Enter Nokia 2760 MAC address (or press Enter to scan):
MAC: 

[*] Scanning for Bluetooth devices...
[*] This may take 10-15 seconds...

[+] Found 3 device(s):

  1. Nokia 2760
     MAC: 00:1A:6B:12:34:56

  2. Alex's Phone
     MAC: 00:1B:DC:AB:CD:EF

  3. Laptop BT
     MAC: 00:1C:4D:12:34:AB

Select device number: 1

[*] Connecting to 00:1A:6B:12:34:56...
[*] Port: 1
[+] Connected successfully!

[?] Use encryption? (y/n): y

============================================================
          BLUETOOTH CHAT - NOKIA 2760 SERVER
============================================================
Commands:
  /quit   - Exit chat
  /status - Check connection
  Encryption: ON
============================================================

You: Hello Nokia!
[*] Encrypted: 3f8a9c2b1e...
Nokia: ACK: Hello Nokia!

You: Testing Bluetooth SPP
[*] Encrypted: 7d2c4f8e...
Nokia: ACK: Testing Bluetooth SPP

You: /quit
[*] Exiting...
[*] Disconnected
```

---

## Project Structure

```
bluetooth_chat_project/
│
├── nokia_server/
│   ├── src/
│   │   ├── BluetoothChatServer.java      # Main server app
│   │   └── MessageEncryption.java        # AES encryption
│   ├── resources/
│   │   └── manifest.mf                   # MIDlet manifest
│   └── build/
│       ├── BTChatServer.jar              # Compiled JAR
│       └── BTChatServer.jad              # JAD descriptor
│
├── laptop_client/
│   ├── bluetooth_client.py               # Main client
│   ├── encryption.py                     # AES encryption
│   └── requirements.txt                  # Python dependencies
│
└── README.md                             # This file
```

---

## Technical Details

### Bluetooth SPP Specifications
- **Profile:** Serial Port Profile (SPP)
- **UUID:** 00001101-0000-1000-8000-00805F9B34FB
- **Protocol:** RFCOMM (Bluetooth serial)
- **Port:** 1 (default)
- **Max throughput:** ~128 Kbps
- **Range:** ~10 meters (Class 2)

### Encryption
- **Algorithm:** AES-128
- **Mode:** ECB (Electronic Codebook)
- **Key:** 16 bytes (`MySecretKey12345`)
- **Encoding:** Hexadecimal string
- **Note:** For production, use CBC/GCM mode with proper IV

### Message Protocol
```
Client → Server: "Hello\n"
Server → Client: "ACK: Hello\n"
```

---

## Troubleshooting

### Nokia 2760 Issues

**"Bluetooth error" on startup:**
- Restart phone
- Enable Bluetooth in Settings
- Check permissions in manifest.mf

**"Connection closed immediately:"**
- Make sure laptop is paired
- Try removing and re-pairing devices
- Check if other Bluetooth apps are running

**"App won't install:"**
- Check JAR/JAD file sizes match
- Verify manifest.mf permissions
- Try signing the JAR (optional)

### Laptop Issues

**"No module named 'bluetooth'":**
```bash
pip install pybluez
```

**"Bluetooth socket error":**
- Enable Bluetooth adapter
- Run as Administrator (Windows)
- Check firewall settings

**PyBluez installation fails on Windows:**
```bash
# Install Visual C++ Build Tools first
# Then try:
pip install pybluez --no-cache-dir
```

**"Device not found":**
- Make sure Nokia app is running
- Phone must be discoverable
- Try increasing scan duration in code

---

## Advanced Features

### Adding Internet Access (Future)

Since Nokia 2760 doesn't support Bluetooth PAN, you can bridge via laptop:

```python
# On laptop, forward data to internet
import requests

def send_to_internet(message):
    response = requests.post('https://your-server.com/api', 
                             json={'message': message})
    return response.text
```

### Multiple Clients

Modify Nokia server to accept multiple connections:

```java
while (true) {
    StreamConnection conn = serverNotifier.acceptAndOpen();
    new Thread(new ClientHandler(conn)).start();
}
```

---

## Security Notes

⚠️ **Important:**

1. **Default encryption is basic** - AES-ECB mode is not recommended for production
2. **Hardcoded key** - Replace with proper key exchange (Diffie-Hellman)
3. **No authentication** - Add HMAC for message integrity
4. **Plaintext option** - Disable for sensitive data

**For production use:**
- Implement TLS/SSL over Bluetooth
- Use AES-GCM or ChaCha20-Poly1305
- Add certificate-based authentication
- Implement perfect forward secrecy

---

## Known Limitations

- Nokia 2760 can handle 1 connection at a time
- Maximum message size: 1024 bytes per transmission
- No persistent storage (messages not saved)
- Encryption is basic (ECB mode, static key)
- Range limited to ~10 meters
- No internet connectivity on Nokia side

---

## Testing Checklist

- [ ] Nokia app installs successfully
- [ ] Server starts and shows device address
- [ ] Laptop discovers Nokia in scan
- [ ] Devices pair successfully
- [ ] Connection establishes (Port 1)
- [ ] Messages send from laptop → Nokia
- [ ] Nokia sends ACK responses
- [ ] Encryption/decryption works
- [ ] Connection survives brief disconnects
- [ ] App handles errors gracefully

---

## License

MIT License - Free to use and modify

---

## Credits

**Developer:** Alex Jonsson (CKCHDX)  
**Organization:** Oscyra Solutions  
**GitHub:** https://github.com/CKCHDX  
**Website:** https://oscyra.solutions/

---

## Support

For issues or questions:
- Open issue on GitHub
- Email: support@oscyra.solutions
- Check Nokia 2760 documentation

---

**Happy Bluetooth Hacking! 📱💬🔐**
