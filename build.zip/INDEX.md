# 📦 BLUETOOTH CHAT PROJECT - COMPLETE PACKAGE

**Project Name:** Nokia 2760 Bluetooth SPP Chat System  
**Developer:** Alex Jonsson (CKCHDX)  
**Created:** November 3, 2025  
**Status:** ✅ READY TO DEPLOY

---

## 📋 Project Overview

This is a complete, working Bluetooth Serial Port Profile (SPP) chat system that allows:
- Nokia 2760 to act as a Bluetooth server
- Laptop (Windows/Linux) to connect as a client
- Encrypted message exchange using AES-128
- No internet required - works over Bluetooth only

---

## 📁 All Project Files (13 files total)

### Documentation (4 files)
1. **README.md** - Complete project documentation with technical specs
2. **QUICKSTART.md** - Fast setup guide for impatient users
3. **PROJECT_SUMMARY.md** - High-level overview and architecture
4. **TROUBLESHOOTING.md** - Solutions to common problems

### Nokia 2760 Server (4 files)
5. **nokia_server/src/BluetoothChatServer.java** - Main application
6. **nokia_server/src/MessageEncryption.java** - AES encryption
7. **nokia_server/resources/manifest.mf** - Permissions & metadata
8. **nokia_server/build.xml** - Apache Ant build script

### Laptop Client (5 files)
9. **laptop_client/bluetooth_client.py** - Main client app
10. **laptop_client/encryption.py** - AES encryption module
11. **laptop_client/requirements.txt** - Python dependencies
12. **laptop_client/run_client.bat** - Windows launcher
13. **laptop_client/run_client.sh** - Linux launcher

---

## 🚀 Quick Start (3 Steps)

### Step 1: Build Nokia App
```bash
cd nokia_server
ant build
# Or use Sun Java Wireless Toolkit 2.5.2
```

### Step 2: Install on Nokia 2760
- Transfer `BTChatServer.jar` + `BTChatServer.jad` via Bluetooth
- Install from Applications menu

### Step 3: Run Laptop Client
```bash
cd laptop_client
pip install -r requirements.txt
python bluetooth_client.py
```

**Done!** Start chatting over Bluetooth SPP! 🎉

---

## 📊 Technical Specifications

| Component | Technology | Details |
|-----------|-----------|---------|
| **Nokia Server** | Java ME (MIDP 2.0) | Bluetooth SPP server |
| **Laptop Client** | Python 3.7+ | PyBluez + PyCryptodome |
| **Protocol** | Bluetooth SPP | RFCOMM channel |
| **UUID** | 0x1101 | Standard SPP UUID |
| **Encryption** | AES-128 ECB | Optional, enabled by user |
| **Range** | ~10 meters | Bluetooth Class 2 |
| **Throughput** | ~128 Kbps | SPP limitation |

---

## 🎯 Features

✅ Bluetooth SPP server on Nokia 2760  
✅ Python client for Windows/Linux  
✅ Optional AES-128 encryption  
✅ Interactive chat interface  
✅ Automatic device discovery  
✅ Connection status monitoring  
✅ Error handling & reconnection  
✅ Full documentation  
✅ Troubleshooting guide  

---

## 🔧 Requirements

### Nokia 2760:
- Nokia 2760 phone (or compatible)
- Bluetooth enabled
- Java ME runtime (built-in)

### Laptop:
- Windows 10/11 or Linux
- Python 3.7 or higher
- Bluetooth adapter
- Internet (for pip install only)

### Development:
- Sun Java Wireless Toolkit 2.5.2 OR Nokia SDK
- Apache Ant (optional, for command-line build)

---

## 📚 File Descriptions

### Core Application Files

**BluetoothChatServer.java** (6.2 KB)
- Main MIDlet application for Nokia 2760
- Implements Bluetooth SPP server
- Handles incoming connections
- Displays messages on screen
- Sends acknowledgments

**MessageEncryption.java** (2.1 KB)
- AES-128 encryption for Java ME
- Hex encoding/decoding
- Compatible with Python client

**bluetooth_client.py** (6.2 KB)
- Python Bluetooth client
- Device discovery
- Connection management
- Interactive chat interface
- Encryption support

**encryption.py** (1.9 KB)
- Python AES-128 encryption
- Matches Nokia encryption
- PyCryptodome based

### Configuration Files

**manifest.mf**
- MIDlet permissions
- Bluetooth access rights
- App metadata

**requirements.txt**
- pybluez==0.23
- pycryptodome==3.19.0

**build.xml**
- Apache Ant build script
- Compiles, preverifies, packages JAR
- Generates JAD descriptor

### Helper Scripts

**run_client.bat** (Windows)
- Checks Python installation
- Installs dependencies
- Launches client

**run_client.sh** (Linux)
- Checks dependencies
- Installs Bluetooth libraries
- Launches client

---

## 🛠️ Build Process

### For Nokia 2760:

**Method 1: GUI (Easiest)**
1. Open Sun WTK or Nokia SDK
2. Create new project: "BTChatServer"
3. Copy source files to project
4. Build → Creates JAR and JAD
5. Transfer to phone

**Method 2: Command Line**
```bash
cd nokia_server

# Using Ant
ant build

# Or manually
javac -bootclasspath midpapi20.jar:cldcapi11.jar \
      -d build src/*.java
preverify -classpath midpapi20.jar -d verified build
jar cmf manifest.mf BTChatServer.jar -C verified .
```

### For Laptop:

```bash
cd laptop_client

# Windows
pip install -r requirements.txt
python bluetooth_client.py

# Linux
sudo apt-get install bluetooth libbluetooth-dev
pip3 install -r requirements.txt
python3 bluetooth_client.py
```

---

## 💬 Usage Example

### Terminal Session

```
============================================================
     Nokia 2760 Bluetooth Chat Client
     Created by CKCHDX
============================================================

[*] Scanning for Bluetooth devices...
[+] Found 1 device(s):

  1. Nokia 2760
     MAC: 00:1A:6B:12:34:56

Select device number: 1

[*] Connecting to 00:1A:6B:12:34:56...
[+] Connected successfully!

[?] Use encryption? (y/n): y

============================================================
Commands:
  /quit   - Exit chat
  /status - Check connection
  Encryption: ON
============================================================

You: Hello from laptop!
Nokia: ACK: Hello from laptop!

You: Testing Bluetooth SPP
Nokia: ACK: Testing Bluetooth SPP

You: /quit
[*] Disconnected
```

---

## 🔐 Security Features

### Current Implementation:
- Bluetooth pairing (PIN-based)
- Optional AES-128 encryption
- Message integrity via acknowledgments

### Limitations:
- Hardcoded encryption key (for demo)
- ECB mode (not recommended for production)
- No key exchange protocol
- No forward secrecy

### For Production:
Replace with TLS/SSL, use AES-GCM, implement Diffie-Hellman key exchange

---

## ⚠️ Known Limitations

1. **Single connection** - Nokia can't handle multiple clients simultaneously
2. **No message history** - Messages not saved, chat session only
3. **10-meter range** - Bluetooth Class 2 limitation
4. **No internet** - Nokia 2760 lacks Bluetooth PAN profile
5. **Basic encryption** - Demo-grade security only

---

## 🐛 Troubleshooting

See **TROUBLESHOOTING.md** for detailed solutions to:
- Build errors
- Installation problems
- Connection issues
- Pairing failures
- Permission errors
- Encryption problems

Common quick fixes:
```bash
# Linux - Restart Bluetooth
sudo systemctl restart bluetooth

# Python - Reinstall packages
pip uninstall pybluez pycryptodome
pip install pybluez pycryptodome

# Nokia - Remove pairing and re-pair
```

---

## 🎓 What You'll Learn

This project teaches:
- Java ME MIDlet development
- Bluetooth SPP protocol
- RFCOMM communication
- AES encryption implementation
- Cross-platform Bluetooth (Python)
- Legacy device programming
- Embedded systems development

---

## 🔄 Next Steps & Extensions

**Easy Enhancements:**
1. Add GUI to laptop client (Tkinter/PyQt)
2. Implement message history
3. Add contact list
4. Create Android client

**Advanced Features:**
1. Multi-client support (threading)
2. File transfer (OBEX protocol)
3. Internet bridge (laptop as gateway)
4. Proper encryption (AES-GCM + key exchange)
5. Voice chat (if Nokia hardware supports)

---

## 📞 Support & Contact

**Developer:** Alex Jonsson (CKCHDX)  
**GitHub:** https://github.com/CKCHDX  
**Website:** https://oscyra.solutions/  
**Email:** support@oscyra.solutions

**Other Projects:**
- PROJECT-AION (AI-powered OS)
- Dynamic-OS (Custom Linux distro)
- Klar-Engine (Search engine)
- CDOX (Cyber defense system)

---

## 📄 License

MIT License - Free to use, modify, and distribute

```
Copyright (c) 2025 Alex Jonsson (CKCHDX)

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction...
```

---

## ✅ Project Checklist

Before you start, make sure you have:

**Hardware:**
- [ ] Nokia 2760 phone
- [ ] Laptop with Bluetooth
- [ ] USB cable (optional, for installation)

**Software:**
- [ ] Java ME SDK (Sun WTK 2.5.2 or Nokia SDK)
- [ ] Python 3.7+
- [ ] Apache Ant (optional)

**Knowledge:**
- [ ] Basic Java programming
- [ ] Basic Python programming
- [ ] Understanding of Bluetooth basics
- [ ] Command-line comfort

---

## 🏆 Success Criteria

Your system is working correctly when:
1. ✅ Nokia app installs without errors
2. ✅ Server starts and shows "Waiting for connection..."
3. ✅ Laptop discovers Nokia in Bluetooth scan
4. ✅ Connection establishes successfully
5. ✅ Messages send from laptop → Nokia
6. ✅ Nokia sends ACK responses back
7. ✅ Encryption works (if enabled)
8. ✅ Connection remains stable

---

## 📈 Project Statistics

- **Total Files:** 13
- **Total Size:** ~40 KB
- **Lines of Code:** ~800 (Java + Python)
- **Documentation:** 4 comprehensive guides
- **Development Time:** 1 day
- **Complexity:** Intermediate
- **Platform:** Cross-platform (Nokia + Windows/Linux)

---

## 🎉 Final Notes

This is a **complete, working system** ready to build and deploy!

All files are included:
✓ Source code  
✓ Build scripts  
✓ Documentation  
✓ Troubleshooting  
✓ Launchers  

No additional files needed!

**Ready to start? Open QUICKSTART.md and follow the steps!**

---

**Happy Bluetooth Hacking! 📱💬🔐**

Last updated: November 3, 2025, 10:40 PM CET
