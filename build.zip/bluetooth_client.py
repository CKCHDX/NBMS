#!/usr/bin/env python3
"""
Bluetooth SPP Client for Laptop
Connects to Nokia 2760 Bluetooth Chat Server
"""

import bluetooth
import sys
import time
from encryption import encrypt_message, decrypt_message

class BluetoothChatClient:
    def __init__(self):
        self.socket = None
        self.connected = False

    def discover_devices(self):
        """Scan for nearby Bluetooth devices"""
        print("\n[*] Scanning for Bluetooth devices...")
        print("[*] This may take 10-15 seconds...")

        try:
            nearby_devices = bluetooth.discover_devices(
                duration=8, 
                lookup_names=True, 
                flush_cache=True
            )

            if not nearby_devices:
                print("[!] No devices found.")
                return []

            print(f"\n[+] Found {len(nearby_devices)} device(s):\n")
            for i, (addr, name) in enumerate(nearby_devices, 1):
                print(f"  {i}. {name}")
                print(f"     MAC: {addr}\n")

            return nearby_devices

        except Exception as e:
            print(f"[!] Error during discovery: {e}")
            return []

    def connect(self, mac_address, port=1):
        """Connect to Nokia 2760 via SPP"""
        print(f"\n[*] Connecting to {mac_address}...")
        print(f"[*] Port: {port}")

        try:
            # Create RFCOMM socket
            self.socket = bluetooth.BluetoothSocket(bluetooth.RFCOMM)
            self.socket.connect((mac_address, port))

            self.connected = True
            print("[+] Connected successfully!\n")
            return True

        except bluetooth.BluetoothError as e:
            print(f"[!] Connection failed: {e}")
            print("[!] Make sure:")
            print("    1. Nokia 2760 app is running")
            print("    2. Device is paired")
            print("    3. Bluetooth is enabled")
            return False
        except Exception as e:
            print(f"[!] Unexpected error: {e}")
            return False

    def send_message(self, message, encrypted=False):
        """Send a message to Nokia"""
        if not self.connected:
            print("[!] Not connected!")
            return False

        try:
            # Optionally encrypt
            if encrypted:
                message = encrypt_message(message)
                print(f"[*] Encrypted: {message[:50]}...")

            # Send message with newline
            self.socket.send((message + "\n").encode('utf-8'))
            return True

        except Exception as e:
            print(f"[!] Send error: {e}")
            self.connected = False
            return False

    def receive_message(self, timeout=5):
        """Receive a message from Nokia"""
        if not self.connected:
            return None

        try:
            self.socket.settimeout(timeout)
            data = self.socket.recv(1024)

            if data:
                message = data.decode('utf-8').strip()
                return message
            return None

        except bluetooth.BluetoothError:
            return None
        except Exception as e:
            print(f"[!] Receive error: {e}")
            return None

    def chat_loop(self, use_encryption=False):
        """Interactive chat interface"""
        print("=" * 60)
        print("          BLUETOOTH CHAT - NOKIA 2760 SERVER")
        print("=" * 60)
        print("Commands:")
        print("  /quit   - Exit chat")
        print("  /status - Check connection")
        print(f"  Encryption: {'ON' if use_encryption else 'OFF'}")
        print("=" * 60)
        print()

        while self.connected:
            try:
                # Get user input
                message = input("You: ").strip()

                if not message:
                    continue

                # Handle commands
                if message == '/quit':
                    print("[*] Exiting...")
                    break
                elif message == '/status':
                    status = "Connected" if self.connected else "Disconnected"
                    print(f"[*] Status: {status}")
                    continue

                # Send message
                if self.send_message(message, encrypted=use_encryption):
                    # Wait for response
                    response = self.receive_message(timeout=3)
                    if response:
                        print(f"Nokia: {response}")
                    else:
                        print("[*] No response")

            except KeyboardInterrupt:
                print("\n[*] Interrupted by user")
                break
            except Exception as e:
                print(f"[!] Error: {e}")
                break

        self.disconnect()

    def disconnect(self):
        """Close the connection"""
        if self.socket:
            try:
                self.socket.close()
            except:
                pass

        self.connected = False
        print("[*] Disconnected")


def main():
    print("=" * 60)
    print("     Nokia 2760 Bluetooth Chat Client")
    print("     Created by CKCHDX")
    print("=" * 60)

    client = BluetoothChatClient()

    # Option 1: Manual MAC address entry
    print("\n[?] Enter Nokia 2760 MAC address (or press Enter to scan):")
    mac_input = input("MAC: ").strip()

    if mac_input:
        mac_address = mac_input
    else:
        # Option 2: Discover devices
        devices = client.discover_devices()

        if not devices:
            print("[!] No devices found. Exiting.")
            return

        # Let user select device
        try:
            choice = int(input("Select device number: ")) - 1
            mac_address = devices[choice][0]
        except (ValueError, IndexError):
            print("[!] Invalid selection")
            return

    # Connect
    if not client.connect(mac_address):
        return

    # Ask about encryption
    encrypt_input = input("\n[?] Use encryption? (y/n): ").lower()
    use_encryption = encrypt_input == 'y'

    # Start chat
    client.chat_loop(use_encryption=use_encryption)


if __name__ == "__main__":
    main()
