import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import javax.bluetooth.*;
import javax.microedition.rms.*;
import java.util.Vector;
import java.io.*;

/**
 * Nokia Bluetooth Chat Application
 * Two-way messaging over Bluetooth SPP
 * CKCHDX - October 2025
 */
public class NokiaBluetoothChat extends MIDlet implements CommandListener, DiscoveryListener {
    
    // Display management
    private Display display;
    
    // Main menu
    private List mainMenu;
    private Command exitCmd;
    
    // Device scanning
    private List deviceList;
    private Command backCmd;
    private Command selectCmd;
    private Command scanCmd;
    private Command stopScanCmd;
    private Vector devices;
    private DiscoveryAgent agent;
    private LocalDevice local;
    private boolean scanning = false;
    
    // Chat interface
    private Form chatForm;
    private TextField inputField;
    private StringItem chatDisplay;
    private Command sendCmd;
    private Command disconnectCmd;
    private StringBuffer chatHistory;
    
    // Connection
    private StreamConnection connection;
    private InputStream inStream;
    private OutputStream outStream;
    private Thread readThread;
    private boolean connected = false;
    
    // Persistent storage
    private static final String DEVICE_STORE = "LastDevice";
    private String lastDeviceAddr = null;
    private String lastDeviceName = null;
    
    // Bluetooth SPP UUID
    private static final String SPP_UUID = "0000110100001000800000805F9B34FB";
    
    /**
     * Constructor - Initialize application
     */
    public NokiaBluetoothChat() {
        display = Display.getDisplay(this);
        devices = new Vector();
        chatHistory = new StringBuffer();
    }
    
    /**
     * Start application - Load saved device and show main menu
     */
    public void startApp() {
        loadLastDevice();
        showMainMenu();
    }
    
    /**
     * Pause application
     */
    public void pauseApp() {
        // Nothing to do
    }
    
    /**
     * Destroy application - Clean up connection
     */
    public void destroyApp(boolean unconditional) {
        disconnect();
    }
    
    // ========================================
    // MAIN MENU
    // ========================================
    
    /**
     * Display main menu with options
     */
    private void showMainMenu() {
        mainMenu = new List("BT Chat", List.IMPLICIT);
        mainMenu.append("Scan for Devices", null);
        
        // Show quick connect option if we have a saved device
        if (lastDeviceAddr != null) {
            mainMenu.append("Connect to: " + lastDeviceName, null);
        }
        
        mainMenu.append("Exit", null);
        mainMenu.setCommandListener(this);
        display.setCurrent(mainMenu);
    }
    
    // ========================================
    // DEVICE SCANNING
    // ========================================
    
    /**
     * Initialize and start device scanning
     */
    private void startScanning() {
        try {
            // Initialize Bluetooth
            local = LocalDevice.getLocalDevice();
            local.setDiscoverable(DiscoveryAgent.GIAC);
            agent = local.getDiscoveryAgent();
            
            // Clear previous results
            devices.removeAllElements();
            
            // Create device list UI
            deviceList = new List("Scanning...", List.IMPLICIT);
            
            // Add commands
            scanCmd = new Command("Refresh", Command.SCREEN, 1);
            stopScanCmd = new Command("Stop", Command.SCREEN, 2);
            selectCmd = new Command("Connect", Command.OK, 3);
            backCmd = new Command("Back", Command.BACK, 4);
            
            deviceList.addCommand(scanCmd);
            deviceList.addCommand(stopScanCmd);
            deviceList.addCommand(selectCmd);
            deviceList.addCommand(backCmd);
            deviceList.setCommandListener(this);
            
            display.setCurrent(deviceList);
            
            // Start scanning
            performScan();
            
        } catch (Exception e) {
            showAlert("Error", "Cannot start Bluetooth: " + e.getMessage());
        }
    }
    
    /**
     * Perform Bluetooth device inquiry
     */
    private void performScan() {
        try {
            scanning = true;
            boolean started = agent.startInquiry(DiscoveryAgent.GIAC, this);
            
            if (!started) {
                showAlert("Error", "Cannot start device inquiry");
                scanning = false;
            }
        } catch (BluetoothStateException e) {
            showAlert("Error", "Bluetooth error: " + e.getMessage());
            scanning = false;
        }
    }
    
    /**
     * DiscoveryListener callback - Device found
     */
    public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
        devices.addElement(btDevice);
        
        try {
            String name = btDevice.getFriendlyName(false);
            deviceList.append(name, null);
        } catch (IOException e) {
            // Use MAC address if name not available
            deviceList.append(btDevice.getBluetoothAddress(), null);
        }
    }
    
    /**
     * DiscoveryListener callback - Inquiry completed
     */
    public void inquiryCompleted(int discType) {
        scanning = false;
        deviceList.setTitle("Found: " + devices.size() + " devices");
        
        if (devices.size() == 0) {
            deviceList.append("No devices found", null);
        }
    }
    
    /**
     * DiscoveryListener callback - Services discovered (not used)
     */
    public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {
        // Not used in this implementation
    }
    
    /**
     * DiscoveryListener callback - Service search completed (not used)
     */
    public void serviceSearchCompleted(int transID, int respCode) {
        // Not used in this implementation
    }
    
    // ========================================
    // CONNECTION MANAGEMENT
    // ========================================
    
    /**
     * Connect to device at given index in device list
     */
    private void connectToDevice(int index) {
        if (index < 0 || index >= devices.size()) {
            return;
        }
        
        final RemoteDevice device = (RemoteDevice) devices.elementAt(index);
        showAlert("Connecting", "Please wait...");
        
        // Connect in background thread
        new Thread() {
            public void run() {
                try {
                    // Get device address
                    String addr = device.getBluetoothAddress();
                    
                    // Build connection URL
                    // Format: btspp://MAC:channel;params
                    String url = "btspp://" + addr + ":1;authenticate=false;encrypt=false;master=false";
                    
                    // Open connection
                    connection = (StreamConnection) Connector.open(url);
                    inStream = connection.openInputStream();
                    outStream = connection.openOutputStream();
                    connected = true;
                    
                    // Save device info for quick reconnect
                    try {
                        lastDeviceAddr = addr;
                        lastDeviceName = device.getFriendlyName(false);
                    } catch (IOException e) {
                        lastDeviceName = addr;
                    }
                    saveLastDevice();
                    
                    // Start chat interface
                    startChat();
                    
                    // Start reading messages
                    startReadThread();
                    
                } catch (Exception e) {
                    connected = false;
                    showAlert("Connection Failed", e.getMessage());
                }
            }
        }.start();
    }
    
    /**
     * Quick connect to last saved device
     */
    private void connectToLastDevice() {
        if (lastDeviceAddr == null) {
            showAlert("Error", "No saved device found");
            return;
        }
        
        showAlert("Connecting", "Connecting to " + lastDeviceName);
        
        // Connect in background thread
        new Thread() {
            public void run() {
                try {
                    // Build connection URL
                    String url = "btspp://" + lastDeviceAddr + ":1;authenticate=false;encrypt=false;master=false";
                    
                    // Open connection
                    connection = (StreamConnection) Connector.open(url);
                    inStream = connection.openInputStream();
                    outStream = connection.openOutputStream();
                    connected = true;
                    
                    // Start chat interface
                    startChat();
                    
                    // Start reading messages
                    startReadThread();
                    
                } catch (Exception e) {
                    connected = false;
                    showAlert("Connection Failed", e.getMessage());
                }
            }
        }.start();
    }
    
    // ========================================
    // CHAT INTERFACE
    // ========================================
    
    /**
     * Initialize and display chat interface
     */
    private void startChat() {
        chatForm = new Form("Chat: " + lastDeviceName);
        
        // Message display area
        chatDisplay = new StringItem(null, "Connected!\n");
        chatDisplay.setLayout(Item.LAYOUT_NEWLINE_AFTER);
        
        // Message input field
        inputField = new TextField("Message:", "", 160, TextField.ANY);
        
        // Commands
        sendCmd = new Command("Send", Command.OK, 1);
        disconnectCmd = new Command("Disconnect", Command.EXIT, 2);
        
        // Build form
        chatForm.append(chatDisplay);
        chatForm.append(inputField);
        chatForm.addCommand(sendCmd);
        chatForm.addCommand(disconnectCmd);
        chatForm.setCommandListener(this);
        
        display.setCurrent(chatForm);
    }
    
    /**
     * Send message from input field
     */
    private void sendMessage() {
        String msg = inputField.getString();
        
        if (msg.length() == 0 || !connected) {
            return;
        }
        
        try {
            // Write message with newline delimiter
            byte[] data = msg.getBytes();
            outStream.write(data);
            outStream.write('\n');
            outStream.flush();
            
            // Display in chat
            appendToChat("You: " + msg);
            
            // Clear input
            inputField.setString("");
            
        } catch (IOException e) {
            showAlert("Send Error", e.getMessage());
        }
    }
    
    /**
     * Start background thread to read incoming messages
     */
    private void startReadThread() {
        readThread = new Thread() {
            public void run() {
                byte[] buffer = new byte[1024];
                int bytes;
                
                while (connected) {
                    try {
                        // Read data from input stream
                        bytes = inStream.read(buffer);
                        
                        if (bytes > 0) {
                            String msg = new String(buffer, 0, bytes).trim();
                            
                            if (msg.length() > 0) {
                                appendToChat(lastDeviceName + ": " + msg);
                            }
                        }
                        
                    } catch (IOException e) {
                        if (connected) {
                            showAlert("Connection Lost", "Read error");
                            disconnect();
                        }
                        break;
                    }
                }
            }
        };
        readThread.start();
    }
    
    /**
     * Append message to chat display
     */
    private void appendToChat(String msg) {
        chatHistory.append(msg).append("\n");
        
        if (chatDisplay != null) {
            chatDisplay.setText(chatHistory.toString());
        }
    }
    
    /**
     * Disconnect and cleanup
     */
    private void disconnect() {
        connected = false;
        
        try {
            if (readThread != null) {
                readThread.interrupt();
            }
            if (inStream != null) {
                inStream.close();
            }
            if (outStream != null) {
                outStream.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (IOException e) {
            // Ignore cleanup errors
        }
        
        // Clear chat history
        chatHistory.setLength(0);
        
        // Return to main menu
        showMainMenu();
    }
    
    // ========================================
    // PERSISTENT STORAGE (RMS)
    // ========================================
    
    /**
     * Load last connected device from RMS
     */
    private void loadLastDevice() {
        RecordStore rs = null;
        
        try {
            rs = RecordStore.openRecordStore(DEVICE_STORE, false);
            
            if (rs.getNumRecords() > 0) {
                byte[] data = rs.getRecord(1);
                String stored = new String(data);
                
                // Parse format: "MAC|NAME"
                int separator = stored.indexOf('|');
                if (separator > 0) {
                    lastDeviceAddr = stored.substring(0, separator);
                    lastDeviceName = stored.substring(separator + 1);
                }
            }
            
        } catch (Exception e) {
            // No stored device or error - ignore
        } finally {
            try {
                if (rs != null) {
                    rs.closeRecordStore();
                }
            } catch (Exception e) {
                // Ignore
            }
        }
    }
    
    /**
     * Save last connected device to RMS
     */
    private void saveLastDevice() {
        RecordStore rs = null;
        
        try {
            // Delete old record store
            try {
                RecordStore.deleteRecordStore(DEVICE_STORE);
            } catch (Exception e) {
                // Doesn't exist - ignore
            }
            
            // Create new record store
            rs = RecordStore.openRecordStore(DEVICE_STORE, true);
            
            // Store format: "MAC|NAME"
            String data = lastDeviceAddr + "|" + lastDeviceName;
            byte[] bytes = data.getBytes();
            rs.addRecord(bytes, 0, bytes.length);
            
        } catch (Exception e) {
            // Ignore save errors
        } finally {
            try {
                if (rs != null) {
                    rs.closeRecordStore();
                }
            } catch (Exception e) {
                // Ignore
            }
        }
    }
    
    // ========================================
    // COMMAND HANDLING
    // ========================================
    
    /**
     * Handle command events
     */
    public void commandAction(Command c, Displayable d) {
        // Exit command
        if (c == exitCmd || c.getLabel().equals("Exit")) {
            disconnect();
            notifyDestroyed();
        }
        
        // Main menu selection
        else if (c == List.SELECT_COMMAND && d == mainMenu) {
            int selected = mainMenu.getSelectedIndex();
            String item = mainMenu.getString(selected);
            
            if (item.equals("Scan for Devices")) {
                startScanning();
            } else if (item.startsWith("Connect to:")) {
                connectToLastDevice();
            } else if (item.equals("Exit")) {
                disconnect();
                notifyDestroyed();
            }
        }
        
        // Back from device list
        else if (c == backCmd) {
            if (scanning) {
                try {
                    agent.cancelInquiry(this);
                } catch (Exception e) {
                    // Ignore
                }
                scanning = false;
            }
            showMainMenu();
        }
        
        // Refresh scan
        else if (c == scanCmd) {
            devices.removeAllElements();
            deviceList.deleteAll();
            deviceList.setTitle("Scanning...");
            performScan();
        }
        
        // Stop scanning
        else if (c == stopScanCmd) {
            if (scanning) {
                try {
                    agent.cancelInquiry(this);
                    scanning = false;
                } catch (Exception e) {
                    // Ignore
                }
            }
        }
        
        // Select device to connect
        else if (c == selectCmd && deviceList.size() > 0) {
            int selected = deviceList.getSelectedIndex();
            if (selected >= 0 && selected < devices.size()) {
                connectToDevice(selected);
            }
        }
        
        // Send message
        else if (c == sendCmd) {
            sendMessage();
        }
        
        // Disconnect from chat
        else if (c == disconnectCmd) {
            disconnect();
        }
    }
    
    // ========================================
    // UTILITY
    // ========================================
    
    /**
     * Show alert message
     */
    private void showAlert(String title, String msg) {
        Alert alert = new Alert(title, msg, null, AlertType.INFO);
        alert.setTimeout(3000);
        display.setCurrent(alert);
    }
}
