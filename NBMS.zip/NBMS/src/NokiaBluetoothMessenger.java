import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.bluetooth.*;
import javax.microedition.io.*;
import java.io.*;
import java.util.Vector;

public class NokiaBluetoothChat extends MIDlet implements CommandListener, DiscoveryListener {
    private Display display;
    private Form mainForm;
    private List deviceList, serviceList;
    private TextBox chatBox;
    private Command scanCmd, exitCmd, nextCmd, connectCmd, sendCmd, backCmd;
    private Vector devices = new Vector();
    private Vector services = new Vector();
    private DiscoveryAgent agent;
    private StreamConnection conn;
    private InputStream in;
    private OutputStream out;
    private RemoteDevice selectedDevice;

    private static final UUID SPP_UUID = new UUID(0x1101);

    public NokiaBluetoothChat() {
        display = Display.getDisplay(this);
    }

    protected void startApp() {
        showMenu();
    }

    protected void pauseApp() {}

    protected void destroyApp(boolean unconditional) {
        cleanup();
    }

    private void showMenu() {
        mainForm = new Form("BT Chat");
        scanCmd = new Command("Scan", Command.SCREEN, 1);
        exitCmd = new Command("Exit", Command.EXIT, 2);
        mainForm.addCommand(scanCmd);
        mainForm.addCommand(exitCmd);
        mainForm.setCommandListener(this);
        mainForm.deleteAll();
        mainForm.append("Press Scan to find devices.");
        display.setCurrent(mainForm);
    }

    public void commandAction(Command c, Displayable d) {
        if (c == exitCmd) {
            notifyDestroyed();
        } else if (d == mainForm && c == scanCmd) {
            startDiscovery();
        } else if (d == deviceList && c == nextCmd) {
            selectedDevice = (RemoteDevice) devices.elementAt(deviceList.getSelectedIndex());
            searchSPPService();
        } else if (d == serviceList && c == connectCmd) {
            String url = (String) services.elementAt(serviceList.getSelectedIndex());
            connectToService(url);
        } else if (d == chatBox && c == sendCmd) {
            sendMessage(chatBox.getString());
        } else if (c == backCmd) {
            showMenu();
        }
    }

    private void startDiscovery() {
        devices.removeAllElements();
        deviceList = new List("Devices", List.IMPLICIT);
        nextCmd = new Command("Next", Command.OK, 1);
        backCmd = new Command("Back", Command.BACK, 2);
        deviceList.addCommand(nextCmd);
        deviceList.addCommand(backCmd);
        deviceList.setCommandListener(this);
        display.setCurrent(deviceList);
        try {
            agent = LocalDevice.getLocalDevice().getDiscoveryAgent();
            agent.startInquiry(DiscoveryAgent.GIAC, this);
        } catch (BluetoothStateException e) {
            showAlert("Error", "Bluetooth unavailable", mainForm);
        }
    }

    public void deviceDiscovered(RemoteDevice rd, DeviceClass dc) {
        try {
            deviceList.append(rd.getFriendlyName(false), null);
        } catch (IOException e) {
            deviceList.append(rd.getBluetoothAddress(), null);
        }
        devices.addElement(rd);
    }

    public void inquiryCompleted(int discType) {
        if (devices.size() == 0) {
            showAlert("No Devices", "None found.", mainForm);
        }
    }

    private void searchSPPService() {
        services.removeAllElements();
        serviceList = new List("Services", List.IMPLICIT);
        connectCmd = new Command("Connect", Command.OK, 1);
        backCmd = new Command("Back", Command.BACK, 2);
        serviceList.addCommand(connectCmd);
        serviceList.addCommand(backCmd);
        serviceList.setCommandListener(this);
        display.setCurrent(serviceList);
        try {
            agent.searchServices(
                new int[] {0x0100},
                new UUID[] {SPP_UUID},
                selectedDevice,
                this
            );
        } catch (BluetoothStateException e) {
            showAlert("Error", "Service search failed", mainForm);
        }
    }

    public void servicesDiscovered(int transID, ServiceRecord[] records) {
        for (int i = 0; i < records.length; i++) {
            String url = records[i].getConnectionURL(ServiceRecord.NOAUTHENTICATE_NOENCRYPT, false);
            DataElement de = records[i].getAttributeValue(0x0100);
            String name = (de != null) ? de.getValue().toString() : "SPP Service";
            if (url != null) {
                services.addElement(url);
                serviceList.append(name, null);
            }
        }
    }

    public void serviceSearchCompleted(int transID, int respCode) {
        if (services.size() == 0) {
            showAlert("No SPP", "No SPP service found.", mainForm);
        }
    }

    private void connectToService(String url) {
        showAlert("Connecting", "Please wait...", mainForm);
        new Thread() {
            public void run() {
                try {
                    conn = (StreamConnection) Connector.open(url);
                    in = conn.openInputStream();
                    out = conn.openOutputStream();
                    showChatUI();
                    startReadThread();
                } catch (IOException e) {
                    showAlert("Conn Failed", e.getMessage(), mainForm);
                }
            }
        }.start();
    }

    private void showChatUI() {
        chatBox = new TextBox("Chat", "", 160, TextField.ANY);
        sendCmd = new Command("Send", Command.OK, 1);
        backCmd = new Command("Back", Command.BACK, 2);
        chatBox.addCommand(sendCmd);
        chatBox.addCommand(backCmd);
        chatBox.setCommandListener(this);
        display.setCurrent(chatBox);
    }

    private void sendMessage(String msg) {
        try {
            out.write((msg + "\n").getBytes());
            out.flush();
        } catch (IOException e) {
            showAlert("Send Err", e.getMessage(), chatBox);
        }
    }

    private void startReadThread() {
        new Thread() {
            public void run() {
                byte[] buffer = new byte[256];
                try {
                    int len;
                    while ((len = in.read(buffer)) != -1) {
                        String m = new String(buffer, 0, len).trim();
                        showAlert("Peer", m, chatBox);
                    }
                } catch (IOException e) {
                    // connection lost
                }
            }
        }.start();
    }

    private void cleanup() {
        try { if (in != null) in.close(); } catch (Exception ignored) {}
        try { if (out != null) out.close(); } catch (Exception ignored) {}
        try { if (conn!= null) conn.close();} catch (Exception ignored) {}
    }

    private void showAlert(String title, String message, Displayable next) {
        Alert alert = new Alert(title, message, null, AlertType.INFO);
        alert.setTimeout(2000);
        display.setCurrent(alert, next);
    }
}
