package com.example.btchat;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.bluetooth.*;
import javax.microedition.io.*;
import java.io.*;
import java.util.Vector;

public class ChatClient extends MIDlet
    implements CommandListener, DiscoveryListener {

    private Display display;
    private Form form;
    private TextField messageField;
    private StringItem statusItem, chatLog, debugItem;
    private List deviceList, serviceList;
    private Command scanCmd, sendCmd, exitCmd, backCmd, selectDeviceCmd, selectServiceCmd;
    private Vector devices = new Vector();
    private Vector services = new Vector();
    private DiscoveryAgent agent;
    private StreamConnection connection;
    private OutputStream out;
    private InputStream in;

    private static final UUID SPP_UUID = new UUID(0x1101);
    private static final byte[] CRLF = new byte[] {'\r', '\n'};

    public ChatClient() {
        display = Display.getDisplay(this);
        form = new Form("BT Chat Client");
        messageField = new TextField("Message:", "", 160, TextField.ANY);
        statusItem = new StringItem("Status:", "Not connected");
        chatLog = new StringItem("Chat:", "");
        debugItem = new StringItem("Debug:", "");

        scanCmd = new Command("Scan", Command.SCREEN, 1);
        sendCmd = new Command("Send", Command.OK, 2);
        exitCmd = new Command("Exit", Command.EXIT, 3);
        backCmd = new Command("Back", Command.BACK, 4);
        selectDeviceCmd = new Command("Select", Command.OK, 1);
        selectServiceCmd = new Command("Connect", Command.OK, 1);

        form.append(statusItem);
        form.append(debugItem);
        form.append(chatLog);
        form.append(messageField);
        form.addCommand(scanCmd);
        form.addCommand(exitCmd);
        form.setCommandListener(this);
    }

    protected void startApp() {
        display.setCurrent(form);
        debug("MIDlet started");
    }

    protected void pauseApp() { 
        debug("pauseApp");
    }

    protected void destroyApp(boolean unconditional) {
        debug("destroyApp");
        try { if (in != null) { in.close(); debug("Input closed"); } } catch (Exception e) { debug("in.close: " + e); }
        try { if (out != null) { out.close(); debug("Output closed"); } } catch (Exception e) { debug("out.close: " + e); }
        try { if (connection != null) { connection.close(); debug("Connection closed"); } } catch (Exception e) { debug("conn.close: " + e); }
    }

    public void commandAction(Command c, Displayable d) {
        if (c == exitCmd) {
            debug("Exit");
            destroyApp(false);
            notifyDestroyed();
        }
        else if (c == scanCmd) {
            debug("Scan pressed");
            startDeviceDiscovery();
        }
        else if (d == deviceList && c == selectDeviceCmd) {
            int idx = deviceList.getSelectedIndex();
            debug("Device selected: " + idx);
            RemoteDevice rd = (RemoteDevice) devices.elementAt(idx);
            debug("MAC: " + rd.getBluetoothAddress());
            connect(rd);
        }
        else if (d == serviceList && c == selectServiceCmd) {
            int idx = serviceList.getSelectedIndex();
            String url = (String) services.elementAt(idx);
            debug("Service selected: " + url);
            connect(url);
        }
        else if (d == form && c == sendCmd) {
            debug("Send pressed");
            sendMessage();
        }
        else if (c == backCmd) {
            debug("Back");
            display.setCurrent(form);
        }
    }

    private void startDeviceDiscovery() {
        devices.removeAllElements();
        deviceList = new List("Devices", List.IMPLICIT);
        deviceList.addCommand(selectDeviceCmd);
        deviceList.addCommand(backCmd);
        deviceList.setCommandListener(this);
        display.setCurrent(deviceList);
        try {
            debug("Starting inquiry");
            agent = LocalDevice.getLocalDevice().getDiscoveryAgent();
            agent.startInquiry(DiscoveryAgent.GIAC, this);
            updateStatus("Scanning...");
        } catch (BluetoothStateException e) {
            debug("BT error: " + e);
            updateStatus("BT unavailable");
        }
    }

    public void deviceDiscovered(RemoteDevice rd, DeviceClass dc) {
        try {
            String name = rd.getFriendlyName(false);
            debug("Found: " + name);
            deviceList.append(name, null);
        } catch (IOException e) {
            String addr = rd.getBluetoothAddress();
            debug("Found (no name): " + addr);
            deviceList.append(addr, null);
        }
        devices.addElement(rd);
    }

    public void inquiryCompleted(int discType) {
        debug("Inquiry complete, found: " + devices.size());
        if (devices.isEmpty()) {
            updateStatus("No devices");
            display.setCurrent(form);
        }
    }

    private void searchServices(RemoteDevice rd) {
        services.removeAllElements();
        serviceList = new List("Services", List.IMPLICIT);
        serviceList.addCommand(selectServiceCmd);
        serviceList.addCommand(backCmd);
        serviceList.setCommandListener(this);
        display.setCurrent(serviceList);
        try {
            debug("Searching SPP");
            agent.searchServices(
                new int[] {0x0100},
                new UUID[] {SPP_UUID},
                rd,
                this
            );
            updateStatus("Searching...");
        } catch (BluetoothStateException e) {
            debug("Search error: " + e);
            updateStatus("Search failed");
            display.setCurrent(form);
        }
    }

    public void servicesDiscovered(int transID, ServiceRecord[] recs) {
        debug("Services found: " + recs.length);
        for (int i = 0; i < recs.length; i++) {
            String url = recs[i].getConnectionURL(
                ServiceRecord.NOAUTHENTICATE_NOENCRYPT, false
            );
            DataElement de = recs[i].getAttributeValue(0x0100);
            String name = (de != null)? de.getValue().toString() : "SPP";
            if (url != null) {
                debug("Service " + i + ": " + url);
                services.addElement(url);
                serviceList.append(name, null);
            }
        }
    }

    public void serviceSearchCompleted(int transID, int respCode) {
        debug("Service search done: " + services.size());
        if (services.isEmpty()) {
            updateStatus("No SPP");
            display.setCurrent(form);
        }
    }

    private void connect(final RemoteDevice rd) {
        new Thread() {
            public void run() {
                try {
                    String addr = rd.getBluetoothAddress();
                    debug("Connecting to: " + addr);
                    
                    StreamConnection tmpConn = null;
                    OutputStream  tmpOut  = null;
                    InputStream   tmpIn   = null;

                    // Probe channels 1–30
                    for (int ch = 1; ch <= 30; ch++) {
                        String url = "btspp://" + addr + ":" + ch +
                                    ";authenticate=false;encrypt=false;";
                        try {
                            debug("Trying channel " + ch);
                            tmpConn = (StreamConnection) Connector.open(url);
                            tmpOut  = tmpConn.openOutputStream();
                            tmpIn   = tmpConn.openInputStream();
                            debug("Success on channel " + ch);
                            final int foundChannel = ch;
                            display.callSerially(new Runnable() {
                                public void run() {
                                    updateStatus("Chan " + foundChannel);
                                    form.addCommand(sendCmd);
                                }
                            });
                            break;
                        } catch (IOException e) {
                            debug("Ch " + ch + " fail");
                        }
                    }

                    if (tmpConn == null) {
                        debug("No channel found");
                        display.callSerially(new Runnable() {
                            public void run() {
                                updateStatus("No channel");
                            }
                        });
                        return;
                    }

                    connection = tmpConn;
                    out        = tmpOut;
                    in         = tmpIn;
                    debug("Streams assigned");

                    // Pause
                    try {
                        debug("Sleeping 200ms");
                        Thread.sleep(200);
                    } catch (InterruptedException ignored) {}

                    // Receive thread
                    new Thread() {
                        public void run() {
                            debug("Receive thread started");
                            byte[] buf = new byte[256];
                            try {
                                while (true) {
                                    debug("Waiting for data...");
                                    int len = in.read(buf);
                                    debug("Read " + len + " bytes");
                                    if (len < 0) {
                                        debug("EOF");
                                        break;
                                    }
                                    final String msg = new String(buf, 0, len, "UTF-8").trim();
                                    debug("Received: " + msg);
                                    display.callSerially(new Runnable() {
                                        public void run() {
                                            appendChat("< " + msg);
                                        }
                                    });
                                }
                            } catch (IOException e) {
                                debug("Recv error: " + e);
                            }
                            debug("Receive thread ended");
                        }
                    }.start();

                    // Send initial PING with retries
                    debug("Sending PING");
                    for (int attempt = 1; attempt <= 3; attempt++) {
                        try {
                            debug("PING attempt " + attempt);
                            out.write("PING".getBytes("UTF-8"));
                            out.write(CRLF);
                            out.flush();
                            debug("PING sent");
                            display.callSerially(new Runnable() {
                                public void run() {
                                    appendChat("> PING");
                                }
                            });
                            break;
                        } catch (IOException e) {
                            debug("PING attempt " + attempt + " failed: " + e);
                            try { Thread.sleep(100); } catch (InterruptedException ignored) {}
                        }
                    }
                } catch (Exception e) {
                    debug("Connect exception: " + e);
                }
            }
        }.start();
    }

    private void sendMessage() {
        final String msg = messageField.getString();
        debug("Send pressed, msg: " + msg + ", out=" + (out != null ? "OK" : "NULL"));
        
        if (out != null && msg.length() > 0) {
            new Thread() {
                public void run() {
                    try {
                        debug("Writing: " + msg);
                        out.write(msg.getBytes("UTF-8"));
                        out.write(CRLF);
                        out.flush();
                        debug("Write success");
                        display.callSerially(new Runnable() {
                            public void run() {
                                appendChat("Me: " + msg);
                                messageField.setString("");
                            }
                        });
                    } catch (final IOException e) {
                        debug("Write error: " + e);
                        display.callSerially(new Runnable() {
                            public void run() {
                                updateStatus("Send error");
                            }
                        });
                    }
                }
            }.start();
        }
    }

    private void updateStatus(String text) {
        statusItem.setText(text);
    }

    private void appendChat(String text) {
        String current = chatLog.getText();
        chatLog.setText(current + text + "\n");
    }

    private void debug(String msg) {
        String current = debugItem.getText();
        debugItem.setText(current + msg + "\n");
    }

    public void serviceSearchCompleted(int transID) {}
    public void deviceDiscovered(RemoteDevice rd) {}
}
