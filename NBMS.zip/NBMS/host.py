import socket
import threading

# Replace with your adapter's MAC address and desired RFCOMM channel
LOCAL_BDADDR = "9C:4E:36:12:34:56"
RFCOMM_CHANNEL = 1

def client_thread(conn, addr):
    print(f"[+] Connected: {addr}")
    try:
        with conn:
            while True:
                data = conn.recv(1024)
                if not data:
                    break
                text = data.decode().strip()
                print(f"Nokia: {text}")
                reply = input("Me: ")
                conn.sendall((reply + "\n").encode())
    except OSError as e:
        print(f"[!] Connection error: {e}")
    finally:
        print("[*] Disconnected")

def start_server():
    server = socket.socket(
        family=socket.AF_BLUETOOTH,
        type=socket.SOCK_STREAM,
        proto=socket.BTPROTO_RFCOMM
    )
    server.bind((LOCAL_BDADDR, RFCOMM_CHANNEL))
    server.listen(1)
    print(f"[*] Listening on {LOCAL_BDADDR} channel {RFCOMM_CHANNEL}")

    try:
        while True:
            conn, addr = server.accept()
            threading.Thread(target=client_thread, args=(conn, addr), daemon=True).start()
    except KeyboardInterrupt:
        print("\n[*] Server shutting down")
    finally:
        server.close()

if __name__ == "__main__":
    start_server()
